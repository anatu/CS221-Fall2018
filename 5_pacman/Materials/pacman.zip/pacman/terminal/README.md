To use pacman_curse (terminal graphics):

1. Replace the original files in your `pacman/` folder with the three files in
this folder (`keyboardAgents.py`, `pacman.py`, `textDisplay.py`). Be careful to
save these original files elsewhere if you would like to revert back to the 
graphical display later. 

Run pacman.py with the -m option and whatever other options you want to use. 
Use the 'a' 'w' 's' and 'd' keys to move around. 